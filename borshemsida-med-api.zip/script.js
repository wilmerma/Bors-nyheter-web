const FINNHUB_API_KEY = "d23adhpr01qgiro2pa6gd23adhpr01qgiro2pa70";
const NEWS_API_KEY = "f336df239c8c496490c31c6e3551541b";

... JavaScript-koden från användarens inlägg ska klistras in här exakt som den var ...