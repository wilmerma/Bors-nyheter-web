// Byt ut mot dina egna API-nycklar här:
const FINNHUB_API_KEY = "DIN_FINNHUB_API_NYCKEL";
const NEWS_API_KEY = "DIN_NEWSAPI_NYCKEL";

const stockSelect = document.getElementById("stock-select");
const buySignalEl = document.getElementById("buy-signal");
const newsContainer = document.getElementById("news-container");

let priceChart = null;

async function fetchFinnhubData(symbol) {
  const now = Math.floor(Date.now() / 1000);
  const thirtyDaysAgo = now - 30 * 24 * 60 * 60;
  const candleURL = `https://finnhub.io/api/v1/stock/candle?symbol=${symbol}&resolution=D&from=${thirtyDaysAgo}&to=${now}&token=${FINNHUB_API_KEY}`;
  const candleResp = await fetch(candleURL);
  const candleData = await candleResp.json();
  if (candleData.s !== "ok") throw new Error("Fel vid hämtning av prisdata");

  const rsiURL = `https://finnhub.io/api/v1/indicator?symbol=${symbol}&resolution=D&from=${thirtyDaysAgo}&to=${now}&indicator=rsi&timeperiod=14&token=${FINNHUB_API_KEY}`;
  const rsiResp = await fetch(rsiURL);
  const rsiData = await rsiResp.json();
  if (rsiData.s !== "ok") throw new Error("Fel vid hämtning av RSI-data");

  const maValues = movingAverage(candleData.c, 14);

  return {
    dates: candleData.t.map(ts => new Date(ts * 1000)),
    closePrices: candleData.c,
    rsi: rsiData.rsi,
    ma14: maValues,
  };
}

function movingAverage(data, period) {
  const ma = [];
  for (let i = 0; i < data.length; i++) {
    if (i < period - 1) {
      ma.push(null);
      continue;
    }
    const window = data.slice(i - period + 1, i + 1);
    const avg = window.reduce((a, b) => a + b, 0) / period;
    ma.push(avg);
  }
  return ma;
}

function renderChart(data, symbol) {
  const ctx = document.getElementById("price-chart").getContext("2d");
  if (priceChart) priceChart.destroy();

  priceChart = new Chart(ctx, {
    type: "line",
    data: {
      labels: data.dates.map(d => d.toISOString().slice(0,10)),
      datasets: [
        {
          label: `${symbol} Stängningspris`,
          data: data.closePrices,
          borderColor: "#007bff",
          fill: false,
          tension: 0.2,
        },
        {
          label: "MA (14 dagar)",
          data: data.ma14,
          borderColor: "#28a745",
          fill: false,
          borderDash: [5,5],
          tension: 0.2,
        },
        {
          label: "RSI (14 dagar)",
          data: data.rsi,
          borderColor: "#dc3545",
          fill: false,
          yAxisID: 'rsi',
          tension: 0.2,
        }
      ]
    },
    options: {
      responsive: true,
      interaction: {
        mode: 'index',
        intersect: false,
      },
      stacked: false,
      scales: {
        y: {
          type: 'linear',
          position: 'left',
          title: { display: true, text: 'Pris (USD)' },
        },
        rsi: {
          type: 'linear',
          position: 'right',
          min: 0, max: 100,
          title: { display: true, text: 'RSI' },
          grid: { drawOnChartArea: false },
        },
        x: { title: { display: true, text: 'Datum' } }
      },
      plugins: { legend: { position: 'top' } }
    }
  });
}

async function fetchNews(symbol) {
  const url = `https://newsapi.org/v2/everything?q=${symbol}&language=en&sortBy=publishedAt&pageSize=5&apiKey=${NEWS_API_KEY}`;
  try {
    const res = await fetch(url);
    const data = await res.json();
    newsContainer.innerHTML = "";
    if (data.articles?.length) {
      data.articles.forEach(article => {
        const div = document.createElement("div");
        div.className = "article";
        div.innerHTML = `<h3><a href="${article.url}" target="_blank" rel="noopener">${article.title}</a></h3><p>${article.description || "Ingen beskrivning tillgänglig."}</p>`;
        newsContainer.appendChild(div);
      });
    } else {
      newsContainer.innerHTML = "<p>Inga nyheter för denna aktie just nu.</p>";
    }
  } catch (err) {
    newsContainer.innerHTML = "<p>Fel vid hämtning av nyheter.</p>";
    console.error(err);
  }
}

function getBuySignal(rsi) {
  if (!rsi?.length) return "Ingen signal tillgänglig";
  const latestRSI = rsi[rsi.length -1];
  if (latestRSI < 30) return "⚠️ Översåld – Möjlig köpsignal!";
  if (latestRSI > 70) return "🚨 Överköpt – Var försiktig med köp.";
  return "ℹ️ Neutral marknad – Ingen tydlig signal.";
}

async function updatePage() {
  const symbol = stockSelect.value;
  buySignalEl.textContent = "Laddar data...";
  newsContainer.innerHTML = "Laddar nyheter...";
  try {
    const data = await fetchFinnhubData(symbol);
    renderChart(data, symbol);
    buySignalEl.textContent = getBuySignal(data.rsi);
    await fetchNews(symbol);
  } catch (err) {
    buySignalEl.textContent = "Fel vid hämtning av data.";
    newsContainer.innerHTML = "<p>Kan inte hämta data just nu.</p>";
    console.error(err);
  }
}

stockSelect.addEventListener("change", updatePage);
updatePage();
